SELECT 
    V.BusinessEntityID, 
    V.Name AS NombreProveedor
FROM 
    Purchasing.Vendor AS V;

